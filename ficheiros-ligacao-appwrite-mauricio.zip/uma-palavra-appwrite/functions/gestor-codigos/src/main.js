import { Client, ID, Query, TablesDB } from "node-appwrite";
import { randomBytes } from "node:crypto";

const DATABASE_ID = process.env.DATABASE_ID;
const TABLE_ID = process.env.TABLE_ID;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

// Os nomes abaixo correspondem às colunas que já existem na tabela.
const F = {
  code: "Código",
  state: "Estado",
  days: "Duração-dias",
  expiry: "Validade"
};

function jsonError(res, message, status = 400) {
  return res.json({ sucesso: false, erro: message }, status);
}

function addDays(base, days) {
  const d = new Date(`${base}T12:00:00.000Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function publicRow(row) {
  const expiry = String(row[F.expiry] || "").slice(0, 10);
  let state = String(row[F.state] || "Ativo");
  if (state !== "Suspenso" && expiry && expiry < todayISO()) state = "Expirado";
  return {
    id: row.$id,
    codigo: row[F.code],
    validade: expiry,
    duracaoDias: Number(row[F.days] || 0),
    estado: state
  };
}

export default async ({ req, res, log, error }) => {
  try {
    if (!ADMIN_TOKEN) return jsonError(res, "Falta configurar ADMIN_TOKEN nas variáveis da função.", 500);
    if (req.headers["x-admin-token"] !== ADMIN_TOKEN) {
      return jsonError(res, "Acesso não autorizado.", 401);
    }
    if (!DATABASE_ID || !TABLE_ID) {
      return jsonError(res, "Faltam DATABASE_ID ou TABLE_ID nas variáveis da função.", 500);
    }

    const client = new Client()
      .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
      .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
      .setKey(process.env.APPWRITE_API_KEY);

    const db = new TablesDB(client);
    const body = req.bodyJson || {};
    const action = body.action;

    if (req.method === "GET" || action === "listar") {
      const all = [];
      let offset = 0;
      while (true) {
        const page = await db.listRows({
          databaseId: DATABASE_ID,
          tableId: TABLE_ID,
          queries: [Query.limit(100), Query.offset(offset)]
        });
        all.push(...page.rows);
        if (all.length >= page.total || page.rows.length === 0) break;
        offset += page.rows.length;
      }
      return res.json({ sucesso: true, codigos: all.map(publicRow) });
    }

    if (action === "gerar") {
      const quantidade = Math.max(1, Math.min(50, Number(body.quantidade) || 1));
      const dias = Math.max(1, Math.min(3650, Number(body.dias) || 30));
      const criados = [];
      for (let i = 0; i < quantidade; i++) {
        const codigo = "UPD-" + randomBytes(5).toString("hex").toUpperCase();
        const row = await db.createRow({
          databaseId: DATABASE_ID,
          tableId: TABLE_ID,
          rowId: ID.unique(),
          data: {
            [F.code]: codigo,
            [F.state]: "Ativo",
            [F.days]: dias,
            [F.expiry]: addDays(todayISO(), dias)
          }
        });
        criados.push(publicRow(row));
      }
      return res.json({ sucesso: true, codigos: criados });
    }

    if (action === "suspender" || action === "reativar" || action === "renovar") {
      const rowId = String(body.id || "");
      if (!rowId) return jsonError(res, "Falta o identificador do código.");
      const old = await db.getRow({ databaseId: DATABASE_ID, tableId: TABLE_ID, rowId });
      let data = {};
      if (action === "suspender") data[F.state] = "Suspenso";
      if (action === "reativar") data[F.state] = "Ativo";
      if (action === "renovar") {
        const dias = Math.max(1, Math.min(3650, Number(body.dias) || Number(old[F.days]) || 30));
        const oldExpiry = String(old[F.expiry] || "").slice(0, 10);
        const start = oldExpiry > todayISO() ? oldExpiry : todayISO();
        data[F.days] = dias;
        data[F.expiry] = addDays(start, dias);
        data[F.state] = "Ativo";
      }
      const updated = await db.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLE_ID,
        rowId,
        data
      });
      return res.json({ sucesso: true, codigo: publicRow(updated) });
    }

    return jsonError(res, "Ação não reconhecida.");
  } catch (e) {
    error(e?.stack || e?.message || String(e));
    return res.json({ sucesso: false, erro: e?.message || "Erro interno." }, 500);
  }
};
