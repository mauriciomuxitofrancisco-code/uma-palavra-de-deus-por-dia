# Uma Palavra de Deus por Dia — ligação Appwrite

## Ficheiros
- `functions/gestor-codigos/src/main.js`: função que lê/cria/atualiza linhas na tabela Appwrite.
- `functions/gestor-codigos/package.json`: dependência `node-appwrite`.
- `painel-admin.html`: painel administrativo ligado à função por HTTP.

## IDs já colocados
- Endpoint: `https://fra.cloud.appwrite.io/v1`
- Project ID: `6b01acb000015409164b`
- Database ID: `6b01b57c001cc4fa98c4`
- Table ID: `6b01b7e30032b7f5e4df`
- Function ID assumido: `gestor-codigos`

Confirma os IDs no Appwrite antes de publicar. Não alteres nem partilhes a chave API.

## Variável de segurança obrigatória
Na função Appwrite, em Settings > Variables, adiciona:
- `ADMIN_TOKEN` = cria uma palavra-passe longa e única, que não uses noutro serviço.

Mantém também as variáveis existentes:
- `APPWRITE_API_KEY`
- `APPWRITE_FUNCTION_API_ENDPOINT`
- `APPWRITE_FUNCTION_PROJECT_ID`
- `DATABASE_ID`
- `TABLE_ID`

A API key deve ter os scopes de leitura e escrita de rows/tables da base de dados. Nunca a coloques no HTML.

## Colunas esperadas
Este código usa exatamente estas chaves de coluna:
- `Código` (texto)
- `Estado` (texto)
- `Duração-dias` (número)
- `Validade` (data/texto no formato AAAA-MM-DD)

Se as chaves internas das colunas forem diferentes dos nomes visíveis, ajusta o objeto `F` no início de `main.js`.

## Publicação
O repositório já importado no Appwrite deve conter esta pasta:
`functions/gestor-codigos/`

A função deve usar `src/main.js` como entrypoint e `npm install` / `npm start` conforme a configuração existente. Cria um novo deployment e ativa-o.

## Painel
Abre `painel-admin.html` num domínio HTTPS autorizado nas plataformas Appwrite. No painel, preenche o token ADMIN_TOKEN. O ID da função está definido no início do script como `gestor-codigos`.
O domínio/URL de origem do painel pode precisar de ser autorizado nas configurações de plataforma do Appwrite.
